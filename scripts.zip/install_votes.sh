pip install selenium
sudo chmod +x fix_test_votes.py
#export geckodriver to PATH

